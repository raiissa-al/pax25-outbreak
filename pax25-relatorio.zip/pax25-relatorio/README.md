# pax25-relatorio

A Pen created on CodePen.

Original URL: [https://codepen.io/raiissa-al/pen/LEYXmKb](https://codepen.io/raiissa-al/pen/LEYXmKb).

Este projeto é um relatório de surto epidemiológico fictício, desenvolvido com HTML básico para prática de estruturação de conteúdo, uso de seções, listas e imagens.